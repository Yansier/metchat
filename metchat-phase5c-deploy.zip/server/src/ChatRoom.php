<?php

declare(strict_types=1);

namespace PrivateChat;

use JsonException;
use Throwable;
use Workerman\Connection\TcpConnection;
use Workerman\Protocols\Http\Request;
use Workerman\Worker;

final class ChatRoom
{
    /** @var array<int, array{connection: TcpConnection, nickname: ?string, room_key: ?string, sender_id: ?string, member_id: string, connected_at: int, joined_at: ?int, last_seen_at: int, join_attempts: int, handshake_authorized: bool, rate_key: ?string, rate_acquired: bool, chat_times: list<int>, typing_times: list<float>, typing_active: bool, typing_expires_at: int, rate_violations: int}> */
    private array $clients = [];
    private readonly RoomManager $rooms;
    private bool $shuttingDown = false;
    private int $membersVersion = 0;
    private int $typingSequence = 0;

    public function __construct(
        private readonly int $maxFrameBytes,
        private readonly int $maxNicknameCharacters,
        private readonly int $maxMessageCharacters,
        private readonly int $heartbeatTimeout,
        int $historyMaxMessages,
        int $historyTtlSeconds,
        int $ghostGraceSeconds,
        int $maxRooms,
        private readonly int $maxTotalConnections,
        int $maxConnectionsPerRoom,
        private readonly int $maxJoinAttemptsPerConnection,
        private readonly int $roomCodeMinLength,
        private readonly int $roomCodeMaxLength,
        private readonly int $unjoinedTimeout,
        private readonly int $maxSendBufferBytes,
        private readonly int $connectionChatLimit,
        private readonly int $connectionChatWindow,
        private readonly int $typingTtlSeconds,
        private readonly int $connectionTypingLimit,
        private readonly int $connectionTypingWindow,
        private readonly OriginPolicy $originPolicy,
        private readonly ClientIpResolver $ipResolver,
        private readonly IpRateLimiter $ipLimiter,
        private readonly AnonymousIdentity $identities,
    ) {
        $this->rooms = new RoomManager(
            $maxRooms,
            $maxConnectionsPerRoom,
            $historyMaxMessages,
            $historyTtlSeconds,
            null,
            null,
            $ghostGraceSeconds,
        );
    }

    public function attach(TcpConnection $connection): void
    {
        $connection->maxPackageSize = $this->maxFrameBytes + 14;
        $connection->maxSendBufferSize = $this->maxSendBufferBytes;
        if ($this->shuttingDown || count($this->clients) >= $this->maxTotalConnections) {
            $this->rejectHandshake($connection, 503, 'Service Unavailable', 'server_capacity');
            return;
        }

        $now = time();
        $rateKey = null;
        $rateAcquired = false;
        $peerIp = $connection->getRemoteIp();
        if (!$this->ipResolver->isTrustedProxy($peerIp)) {
            $clientIp = $this->ipResolver->resolve($peerIp, null);
            if ($clientIp === null) {
                $this->rejectHandshake($connection, 403, 'Forbidden', 'invalid_peer');
                return;
            }
            $result = $this->ipLimiter->acquireConnection($clientIp);
            if (!$result['allowed']) {
                $this->rejectHandshake($connection, 429, 'Too Many Requests', 'connection_rate_limited');
                return;
            }
            $rateKey = $result['key'];
            $rateAcquired = true;
        }

        $this->clients[$connection->id] = [
            'connection' => $connection, 'nickname' => null, 'room_key' => null, 'sender_id' => null,
            'member_id' => $this->generateMemberId(), 'connected_at' => $now, 'joined_at' => null,
            'last_seen_at' => $now, 'join_attempts' => 0,
            'handshake_authorized' => false, 'rate_key' => $rateKey, 'rate_acquired' => $rateAcquired,
            'chat_times' => [], 'typing_times' => [], 'typing_active' => false, 'typing_expires_at' => 0,
            'rate_violations' => 0,
        ];
    }

    public function authorizeHandshake(TcpConnection $connection, Request $request): void
    {
        if (!isset($this->clients[$connection->id])) {
            $this->rejectHandshake($connection, 503, 'Service Unavailable', 'connection_rejected');
            return;
        }
        $client = &$this->clients[$connection->id];
        if (!$client['rate_acquired']) {
            $xRealIp = $request->header('x-real-ip');
            $clientIp = $this->ipResolver->resolve($connection->getRemoteIp(), is_string($xRealIp) ? $xRealIp : null);
            if ($clientIp === null) {
                $this->rejectHandshake($connection, 403, 'Forbidden', 'proxy_ip_rejected');
                return;
            }
            $result = $this->ipLimiter->acquireConnection($clientIp);
            if (!$result['allowed']) {
                $this->rejectHandshake($connection, 429, 'Too Many Requests', 'connection_rate_limited');
                return;
            }
            $client['rate_key'] = $result['key'];
            $client['rate_acquired'] = true;
        }

        // Count the connection attempt before checking Origin so reconnecting
        // with a forged/missing Origin cannot bypass the per-IP window.
        $origin = $request->header('origin');
        if (!$this->originPolicy->allows(is_string($origin) ? $origin : null)) {
            $this->rejectHandshake($connection, 403, 'Forbidden', 'origin_rejected');
            return;
        }
        $client['handshake_authorized'] = true;
    }

    public function afterWebSocketConnected(TcpConnection $connection): void
    {
        if (($this->clients[$connection->id]['handshake_authorized'] ?? false) !== true) {
            $this->safeClose($connection);
        }
    }

    public function detach(TcpConnection $connection): void
    {
        $client = $this->clients[$connection->id] ?? null;
        if ($client === null) {
            return;
        }
        unset($this->clients[$connection->id]);
        if ($client['rate_acquired'] && $client['rate_key'] !== null) {
            $this->ipLimiter->releaseConnection($client['rate_key']);
        }
        if ($client['nickname'] !== null && $client['room_key'] !== null) {
            if ($client['typing_active']) {
                $this->broadcastTypingState($client['room_key'], $client, false, $connection->id);
            }
            $this->rooms->leave($client['room_key'], $connection->id);
            $this->broadcastPresence($client['room_key'], 'leave', $client['nickname']);
            $this->sendMembersSnapshot($client['room_key']);
        }
    }

    public function handle(TcpConnection $connection, string $rawFrame): void
    {
        if (!isset($this->clients[$connection->id]) || !$this->clients[$connection->id]['handshake_authorized']) {
            $this->safeClose($connection);
            return;
        }
        if (strlen($rawFrame) > $this->maxFrameBytes) {
            $this->sendErrorAndClose($connection, 'frame_too_large', '请求内容过长');
            return;
        }
        try {
            $packet = json_decode($rawFrame, true, 8, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            $this->sendError($connection, 'invalid_json', '请求格式无效');
            return;
        }
        unset($rawFrame);
        if (!is_array($packet) || array_is_list($packet) || count($packet) > 5 || !isset($packet['type']) || !is_string($packet['type'])) {
            $this->sendError($connection, 'invalid_packet', '消息结构无效');
            return;
        }

        switch ($packet['type']) {
            case 'join':
                if (
                    !$this->hasOnlyKeys($packet, ['type', 'nickname', 'roomCode', 'identityToken', 'createOptions'])
                    || (array_key_exists('identityToken', $packet) && !is_string($packet['identityToken']))
                    || (array_key_exists('createOptions', $packet) && !is_array($packet['createOptions']))
                ) {
                    $this->sendError($connection, 'invalid_packet', '消息结构无效'); return;
                }
                $this->handleJoin($connection, $packet); return;
            case 'chat':
                if (
                    !$this->hasOnlyKeys($packet, ['type', 'text', 'replyToId', 'requestId'])
                    || (array_key_exists('replyToId', $packet) && !is_string($packet['replyToId']))
                    || (array_key_exists('requestId', $packet) && !is_string($packet['requestId']))
                ) {
                    $this->sendError($connection, 'invalid_packet', '消息结构无效'); return;
                }
                $this->handleChat($connection, $packet); return;
            case 'typing':
                if (!$this->hasOnlyKeys($packet, ['type', 'active']) || !is_bool($packet['active'] ?? null)) {
                    $this->sendError($connection, 'invalid_packet', '消息结构无效'); return;
                }
                $this->handleTyping($connection, $packet['active']); return;
            case 'ping':
                if (!$this->hasOnlyKeys($packet, ['type', 'ts']) || (isset($packet['ts']) && !is_int($packet['ts']) && !is_float($packet['ts']))) {
                    $this->sendError($connection, 'invalid_packet', '消息结构无效'); return;
                }
                $this->clients[$connection->id]['last_seen_at'] = time();
                $this->sendJson($connection, ['type' => 'pong', 'ts' => $packet['ts'] ?? null]); return;
            case 'pong':
                if (!$this->hasOnlyKeys($packet, ['type', 'ts'])) {
                    $this->sendError($connection, 'invalid_packet', '消息结构无效'); return;
                }
                $this->clients[$connection->id]['last_seen_at'] = time(); return;
            default:
                $this->sendError($connection, 'unsupported_type', '不支持的消息类型');
        }
    }

    public function closeStaleConnections(): void
    {
        $now = time();
        foreach ($this->clients as $client) {
            $stale = $client['room_key'] === null
                ? $client['connected_at'] < $now - $this->unjoinedTimeout
                : $client['last_seen_at'] < $now - $this->heartbeatTimeout;
            if ($stale) {
                $this->safeClose($client['connection']);
            }
        }
    }

    /** @return array{expiredMessages: int, releasedRooms: int, destroyedGhostRooms: int} */
    public function pruneExpiredMessages(): array
    {
        $this->ipLimiter->prune();
        return $this->rooms->pruneExpired();
    }

    /** @return array{destroyedGhostRooms: int} */
    public function pruneRoomLifecycle(): array
    {
        return $this->rooms->pruneLifecycle();
    }

    public function pruneTypingStates(): void
    {
        $now = time();
        foreach (array_keys($this->clients) as $connectionId) {
            $client = $this->clients[$connectionId] ?? null;
            if ($client !== null && $client['typing_active'] && $client['typing_expires_at'] <= $now) {
                $this->clearTyping($connectionId, true);
            }
        }
    }

    public function handleBufferFull(TcpConnection $connection): void
    {
        $this->diagnostic('slow_client_closed');
        $this->safeClose($connection);
    }

    public function handleTransportError(TcpConnection $connection): void
    {
        $this->diagnostic('transport_error');
    }

    public function shutdown(): void
    {
        $this->shuttingDown = true;
        foreach ($this->clients as $client) {
            $this->sendErrorAndClose($client['connection'], 'server_shutdown', '服务器正在停止，请稍后重连');
        }
    }

    /** @param array<string, mixed> $packet */
    private function handleJoin(TcpConnection $connection, array $packet): void
    {
        $client = $this->clients[$connection->id];
        if ($client['room_key'] !== null) {
            $this->sendError($connection, 'already_joined', '当前连接已经加入房间'); return;
        }
        ++$this->clients[$connection->id]['join_attempts'];
        if ($this->clients[$connection->id]['join_attempts'] > $this->maxJoinAttemptsPerConnection) {
            $this->sendErrorAndClose($connection, 'too_many_join_attempts', '加入尝试过于频繁，请稍后重试'); return;
        }
        if ($client['rate_key'] === null || !$this->ipLimiter->allowJoin($client['rate_key'])) {
            $this->sendErrorAndClose($connection, 'join_rate_limited', '加入尝试过于频繁，请稍后重试'); return;
        }

        $nickname = is_string($packet['nickname'] ?? null) ? trim($packet['nickname']) : '';
        $roomCode = is_string($packet['roomCode'] ?? null) ? $packet['roomCode'] : '';
        if ($nickname === '' || !$this->isValidUtf8($nickname)) {
            $this->sendError($connection, 'invalid_nickname', '请输入有效昵称'); return;
        }
        if ($this->unicodeLength($nickname) > $this->maxNicknameCharacters) {
            $this->sendError($connection, 'nickname_too_long', '昵称过长'); return;
        }
        if (!$this->isValidRoomCode($roomCode)) {
            $this->sendError($connection, 'invalid_room_code', '房间暗号格式无效'); return;
        }

        $createOptions = null;
        if (array_key_exists('createOptions', $packet)) {
            $candidate = $packet['createOptions'];
            if (array_is_list($candidate) || count($candidate) < 2 || count($candidate) > 3) {
                $this->sendError($connection, 'invalid_create_options', '房间创建设置无效'); return;
            }
            if (!$this->hasOnlyKeys($candidate, ['mode', 'ttlSeconds', 'requestId'])) {
                $this->sendError($connection, 'invalid_create_options', '房间创建设置无效'); return;
            }
            if (
                !is_string($candidate['mode'] ?? null)
                || !is_int($candidate['ttlSeconds'] ?? null)
                || (array_key_exists('requestId', $candidate) && !is_string($candidate['requestId']))
            ) {
                $this->sendError($connection, 'invalid_create_options', '房间创建设置无效'); return;
            }
            if (!in_array($candidate['mode'], [RoomManager::MODE_NORMAL, RoomManager::MODE_GHOST], true)) {
                $this->sendError($connection, 'invalid_room_mode', '房间模式无效'); return;
            }
            if (!in_array($candidate['ttlSeconds'], RoomManager::ALLOWED_TTL_SECONDS, true)) {
                $this->sendError($connection, 'invalid_room_ttl', '消息有效期无效'); return;
            }
            if (isset($candidate['requestId']) && preg_match('/\A[a-f0-9]{32}\z/D', $candidate['requestId']) !== 1) {
                $this->sendError($connection, 'invalid_create_request_id', '房间创建请求标识无效'); return;
            }
            $createOptions = ['mode' => $candidate['mode'], 'ttlSeconds' => $candidate['ttlSeconds']];
            if (isset($candidate['requestId'])) {
                $createOptions['requestId'] = $candidate['requestId'];
            }
        }

        $identityToken = is_string($packet['identityToken'] ?? null) ? $packet['identityToken'] : null;
        $identity = $this->identities->resolve($identityToken);
        unset($identityToken);

        $joinResult = $this->rooms->join($roomCode, $connection->id, $createOptions);
        unset($roomCode);
        if ($joinResult['status'] === RoomManager::ROOM_LIMIT_REACHED) {
            $this->sendError($connection, 'room_capacity', '当前房间数量已达上限，请稍后重试'); return;
        }
        if ($joinResult['status'] === RoomManager::ROOM_FULL) {
            $this->sendError($connection, 'room_full', '当前房间在线人数已达上限'); return;
        }
        if ($joinResult['status'] === RoomManager::ROOM_ALREADY_EXISTS) {
            $this->sendError($connection, 'room_already_exists', '该暗号对应的房间已存在，请改为加入房间或使用其他暗号'); return;
        }

        $roomKey = $joinResult['roomKey'];
        $senderId = $this->identities->senderId($identity['subject'], $roomKey);
        $joinedAtUnix = time();
        $this->clients[$connection->id]['nickname'] = $nickname;
        $this->clients[$connection->id]['room_key'] = $roomKey;
        $this->clients[$connection->id]['sender_id'] = $senderId;
        $this->clients[$connection->id]['joined_at'] = $joinedAtUnix;
        $this->clients[$connection->id]['last_seen_at'] = $joinedAtUnix;
        $joinedAt = gmdate('c', $joinedAtUnix);
        $this->sendJson($connection, [
            'type' => 'join',
            'nickname' => $nickname,
            'roomId' => $joinResult['roomId'],
            'roomInstanceId' => $joinResult['roomInstanceId'],
            'roomMode' => $joinResult['roomMode'],
            'ttlSeconds' => $joinResult['ttlSeconds'],
            'ghostGraceSeconds' => $joinResult['ghostGraceSeconds'],
            'self' => true,
            'joinedAt' => $joinedAt,
            'senderId' => $senderId,
            'memberId' => $this->clients[$connection->id]['member_id'],
            'identityToken' => $identity['token'],
            'identityExpiresAt' => $identity['expiresAt'],
            'identityRestored' => $identity['restored'],
        ]);
        unset($identity);
        $this->sendJson($connection, [
            'type' => 'history',
            'serverTime' => gmdate('c'),
            'messages' => $this->rooms->history($roomKey),
        ]);
        $this->broadcastToRoom($roomKey, ['type' => 'join', 'nickname' => $nickname, 'self' => false, 'joinedAt' => $joinedAt], $connection->id);
        $this->broadcastPresence($roomKey, 'join', $nickname);
        $this->sendMembersSnapshot($roomKey);
    }

    /** @param array<string, mixed> $packet */
    private function handleChat(TcpConnection $connection, array $packet): void
    {
        $requestId = null;
        if (array_key_exists('requestId', $packet)) {
            $requestId = $packet['requestId'];
            if (preg_match('/\A[a-f0-9]{32}\z/D', $requestId) !== 1) {
                $this->sendError($connection, 'invalid_request_id', '发送请求标识无效'); return;
            }
        }

        $client = $this->clients[$connection->id];
        if ($client['nickname'] === null || $client['room_key'] === null || $client['sender_id'] === null) {
            $this->sendChatFailure($connection, $requestId, 'join_required', '请先加入房间'); return;
        }
        if (!$this->allowConnectionChat($connection->id) || $client['rate_key'] === null || !$this->ipLimiter->allowChat($client['rate_key'])) {
            ++$this->clients[$connection->id]['rate_violations'];
            if ($this->clients[$connection->id]['rate_violations'] >= 3) {
                $this->sendChatFailureAndClose($connection, $requestId, 'chat_rate_limited', '发送过于频繁，请稍后重试');
            } else {
                $this->sendChatFailure($connection, $requestId, 'chat_rate_limited', '发送过于频繁，请稍后重试');
            }
            return;
        }

        $text = is_string($packet['text'] ?? null) ? trim($packet['text']) : '';
        if ($text === '' || !$this->isValidUtf8($text)) {
            $this->sendChatFailure($connection, $requestId, 'empty_message', '消息不能为空'); return;
        }
        if ($this->unicodeLength($text) > $this->maxMessageCharacters) {
            $this->sendChatFailure($connection, $requestId, 'message_too_long', '消息过长'); return;
        }

        $replyToId = null;
        if (array_key_exists('replyToId', $packet)) {
            $replyToId = $packet['replyToId'];
            if (preg_match('/\A[a-f0-9]{32}\z/D', $replyToId) !== 1) {
                $this->sendChatFailure($connection, $requestId, 'invalid_reply_target', '引用消息标识无效'); return;
            }
            if ($this->rooms->message($client['room_key'], $replyToId) === null) {
                $this->sendChatFailure($connection, $requestId, 'reply_target_unavailable', '原消息已过期或不在最近记录中'); return;
            }
        }

        $this->clients[$connection->id]['last_seen_at'] = time();
        $this->clearTyping($connection->id, true);
        $message = $this->rooms->addMessage(
            $client['room_key'],
            $client['nickname'],
            $text,
            $client['sender_id'],
            $replyToId,
        );
        if ($requestId !== null) {
            $this->sendJson($connection, [
                'type' => 'chat_result',
                'requestId' => $requestId,
                'ok' => true,
                'messageId' => $message['id'],
                'serverTime' => gmdate('c'),
            ]);
        }
        $this->broadcastToRoom($client['room_key'], array_merge(['type' => 'chat'], $message));
    }

    private function sendChatFailure(
        TcpConnection $connection,
        ?string $requestId,
        string $code,
        string $message,
    ): void {
        if ($requestId === null) {
            $this->sendError($connection, $code, $message);
            return;
        }

        $this->sendJson($connection, [
            'type' => 'chat_result',
            'requestId' => $requestId,
            'ok' => false,
            'code' => $code,
            'message' => $message,
            'serverTime' => gmdate('c'),
        ]);
    }

    private function sendChatFailureAndClose(
        TcpConnection $connection,
        ?string $requestId,
        string $code,
        string $message,
    ): void {
        if ($requestId === null) {
            $this->sendErrorAndClose($connection, $code, $message);
            return;
        }

        try {
            $connection->close($this->encode([
                'type' => 'chat_result',
                'requestId' => $requestId,
                'ok' => false,
                'code' => $code,
                'message' => $message,
                'serverTime' => gmdate('c'),
            ]));
        } catch (Throwable) {
            $this->safeClose($connection);
        }
    }

    private function handleTyping(TcpConnection $connection, bool $active): void
    {
        $client = $this->clients[$connection->id];
        if ($client['nickname'] === null || $client['room_key'] === null || $client['sender_id'] === null) {
            $this->sendError($connection, 'join_required', '请先加入房间'); return;
        }
        if (!$this->allowConnectionTyping($connection->id)) {
            $this->sendError($connection, 'typing_rate_limited', '输入状态更新过于频繁'); return;
        }
        $this->clients[$connection->id]['last_seen_at'] = time();

        if (!$active) {
            $this->clearTyping($connection->id, true);
            return;
        }

        $wasActive = $this->clients[$connection->id]['typing_active'];
        $this->clients[$connection->id]['typing_active'] = true;
        $this->clients[$connection->id]['typing_expires_at'] = time() + $this->typingTtlSeconds;
        if (!$wasActive) {
            $this->broadcastTypingState(
                $client['room_key'],
                $this->clients[$connection->id],
                true,
                $connection->id,
            );
        }
    }

    private function allowConnectionChat(int $connectionId): bool
    {
        $now = time();
        $times = array_values(array_filter($this->clients[$connectionId]['chat_times'], fn (int $timestamp): bool => $timestamp > $now - $this->connectionChatWindow));
        if (count($times) >= $this->connectionChatLimit) {
            $this->clients[$connectionId]['chat_times'] = $times; return false;
        }
        $times[] = $now;
        $this->clients[$connectionId]['chat_times'] = $times;
        return true;
    }

    private function allowConnectionTyping(int $connectionId): bool
    {
        $now = microtime(true);
        $times = array_values(array_filter(
            $this->clients[$connectionId]['typing_times'],
            fn (float $timestamp): bool => $timestamp > $now - $this->connectionTypingWindow,
        ));
        if (count($times) >= $this->connectionTypingLimit) {
            $this->clients[$connectionId]['typing_times'] = $times;
            return false;
        }

        $times[] = $now;
        $this->clients[$connectionId]['typing_times'] = $times;
        return true;
    }

    private function clearTyping(int $connectionId, bool $broadcast): void
    {
        $client = $this->clients[$connectionId] ?? null;
        if ($client === null || !$client['typing_active']) {
            return;
        }

        $this->clients[$connectionId]['typing_active'] = false;
        $this->clients[$connectionId]['typing_expires_at'] = 0;
        if ($broadcast && $client['room_key'] !== null && $client['nickname'] !== null && $client['sender_id'] !== null) {
            $this->broadcastTypingState($client['room_key'], $client, false, $connectionId);
        }
    }

    /** @param array<string, mixed> $client */
    private function broadcastTypingState(string $roomKey, array $client, bool $active, int $excludeConnectionId): void
    {
        $packet = [
            'type' => 'typing',
            'active' => $active,
            'memberId' => $client['member_id'],
            'nickname' => $client['nickname'],
            'senderId' => $client['sender_id'],
            'sequence' => ++$this->typingSequence,
        ];
        if ($active) {
            $packet['expiresAt'] = gmdate('c', $client['typing_expires_at']);
        }

        $this->broadcastToRoom($roomKey, $packet, $excludeConnectionId);
    }

    private function sendMembersSnapshot(string $roomKey): void
    {
        $members = [];
        foreach ($this->clients as $client) {
            if (
                $client['room_key'] !== $roomKey
                || $client['nickname'] === null
                || $client['sender_id'] === null
                || $client['joined_at'] === null
            ) {
                continue;
            }
            $members[] = [
                'memberId' => $client['member_id'],
                'nickname' => $client['nickname'],
                'senderId' => $client['sender_id'],
                'joinedAt' => gmdate('c', $client['joined_at']),
                'lastSeenAt' => gmdate('c', $client['last_seen_at']),
            ];
        }

        usort($members, static fn (array $left, array $right): int =>
            [$left['joinedAt'], $left['memberId']] <=> [$right['joinedAt'], $right['memberId']]
        );
        $version = ++$this->membersVersion;
        $generatedAt = gmdate('c');
        $count = count($members);

        foreach ($this->clients as $client) {
            if ($client['room_key'] !== $roomKey || $client['nickname'] === null) {
                continue;
            }
            $this->sendJson($client['connection'], [
                'type' => 'members',
                'version' => $version,
                'generatedAt' => $generatedAt,
                'count' => $count,
                'selfMemberId' => $client['member_id'],
                'members' => $members,
            ]);
        }
    }

    private function broadcastPresence(string $roomKey, string $event, string $nickname): void
    {
        $this->broadcastToRoom($roomKey, ['type' => 'presence', 'event' => $event, 'nickname' => $nickname, 'count' => $this->rooms->onlineCount($roomKey)]);
    }

    /** @param array<string, mixed> $packet */
    private function broadcastToRoom(string $roomKey, array $packet, ?int $excludeConnectionId = null): void
    {
        $encoded = $this->encode($packet);
        foreach ($this->clients as $connectionId => $client) {
            if ($connectionId === $excludeConnectionId || $client['room_key'] !== $roomKey || $client['nickname'] === null) {
                continue;
            }
            try {
                if ($client['connection']->send($encoded) === false) {
                    $this->safeClose($client['connection']);
                }
            } catch (Throwable) {
                $this->diagnostic('send_failed');
                $this->safeClose($client['connection']);
            }
        }
        unset($encoded);
    }

    /** @param array<string, mixed> $packet */
    private function sendJson(TcpConnection $connection, array $packet): bool
    {
        try {
            if ($connection->send($this->encode($packet)) === false) {
                $this->safeClose($connection); return false;
            }
            return true;
        } catch (Throwable) {
            $this->diagnostic('send_failed');
            $this->safeClose($connection); return false;
        }
    }

    private function sendError(TcpConnection $connection, string $code, string $message): void
    {
        $this->sendJson($connection, ['type' => 'error', 'code' => $code, 'message' => $message]);
    }

    private function sendErrorAndClose(TcpConnection $connection, string $code, string $message): void
    {
        try {
            $connection->close($this->encode(['type' => 'error', 'code' => $code, 'message' => $message]));
        } catch (Throwable) {
            $this->safeClose($connection);
        }
    }

    private function rejectHandshake(TcpConnection $connection, int $status, string $reason, string $event): void
    {
        $this->diagnostic($event);
        $body = $status === 429 ? 'Request limit exceeded.' : 'WebSocket connection rejected.';
        $response = "HTTP/1.1 {$status} {$reason}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: " . strlen($body) . "\r\nConnection: close\r\n\r\n{$body}";
        try {
            $connection->close($response, true);
        } catch (Throwable) {
            $this->safeClose($connection);
        }
    }

    private function safeClose(TcpConnection $connection): void
    {
        try {
            $connection->close();
        } catch (Throwable) {
            $this->diagnostic('close_failed');
        }
    }

    private function diagnostic(string $event): void
    {
        Worker::safeEcho("[private-chat] event={$event}\n");
    }

    /** @param array<string, mixed> $packet @param list<string> $allowed */
    private function hasOnlyKeys(array $packet, array $allowed): bool
    {
        foreach (array_keys($packet) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                return false;
            }
        }
        return true;
    }

    /** @param array<string, mixed> $packet */
    private function encode(array $packet): string
    {
        return json_encode($packet, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    private function isValidRoomCode(string $roomCode): bool
    {
        $length = strlen($roomCode);
        return $length >= $this->roomCodeMinLength && $length <= $this->roomCodeMaxLength && preg_match('/\A[A-Za-z0-9_-]+\z/D', $roomCode) === 1;
    }

    private function isValidUtf8(string $value): bool
    {
        return preg_match('//u', $value) === 1;
    }

    private function unicodeLength(string $value): int
    {
        $result = preg_match_all('/./us', $value, $matches);
        unset($matches);
        return $result === false ? PHP_INT_MAX : $result;
    }

    private function generateMemberId(): string
    {
        do {
            $memberId = bin2hex(random_bytes(16));
        } while (in_array($memberId, array_column($this->clients, 'member_id'), true));

        return $memberId;
    }
}
